<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ChatGPTController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/migrate', function () {
    \Artisan::call('migrate');
    dd('migrated!');
});


Route::get('/migrate-rollback', function () {
    \Artisan::call('migrate:rollback');
    dd('migrate rollback!');
});

Route::get('/migrate-fresh', function () {
    \Artisan::call('migrate:fresh');
    dd('migrate fresh!');
});

Route::get('/seed', function () {
    \Artisan::call('db:seed');
    dd('seeded!');
});

Route::get('composer', function () {
    shell_exec('composer install');
    dd('executed');
});

Route::get('cache_clear', function () {
    \Artisan::call('optimize:clear');
    dd("All Compile data and Cache is cleared");
});


Route::get('/', function () {
    return view('welcome');
});

Route::get('test', function () {
    dd('abc');
});

Route::get('chat-gpt-tune', [ChatGPTController::class, 'fine_tune']);

