<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthenticationController;
use App\Http\Controllers\API\ProfileController;
use App\Http\Controllers\API\GoalController;
use App\Http\Controllers\API\JournalController;
use App\Http\Controllers\API\SlotController;
use App\Http\Controllers\API\NotesController;
use App\Http\Controllers\API\ChatController;
use App\Http\Controllers\API\UserController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/
Route::group(['middleware' => ['json.response']], function () {

    Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
        return $request->user();
    });

    Route::post('login', [AuthenticationController::class, 'login']);
    Route::post('register', [AuthenticationController::class, 'register']);
    Route::get('forgot-password',[AuthenticationController::class,'forgotPassword']);
    Route::post('reset-password',[AuthenticationController::class,'resetPassword']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::get('logout', [AuthenticationController::class, 'logout']);
        Route::post('update-profile',[ProfileController::class,'updateProfile']);
        Route::post('change-password',[ProfileController::class,'changePassword']);

        Route::get('goal-list',[GoalController::class,'index']);
        Route::post('goal-create',[GoalController::class,'save']);
        Route::post('goal-update',[GoalController::class,'update']);
        Route::get('goal-delete',[GoalController::class,'delete']);

        Route::get('get-journal',[JournalController::class,'index']);
        Route::post('journal-create',[JournalController::class,'save']);

        Route::get('get-slots',[SlotController::class,'index']);
        Route::get('get-slots-data',[SlotController::class,'getSlotsData']);

        Route::get('notes-list',[NotesController::class,'index']);
        Route::post('notes-create',[NotesController::class,'save']);
        Route::post('notes-update',[NotesController::class,'update']);
        Route::get('notes-delete',[NotesController::class,'delete']);

        Route::get('update-journal-task',[JournalController::class,'updateTask']);


        Route::get('fetch-chat',[ChatController::class,'fetchChat']);
        Route::post('generate-message-response',[ChatController::class,'generateResponse']);


        Route::get('delete-account',[ProfileController::class,'deleteAccount']);

        Route::get('unfriend',[UserController::class,'unfriend']);
        Route::get('friend_list',[UserController::class,'friendList']);

        Route::get('delete-journal',[JournalController::class,'deleteJournal']);

        Route::get('send-invitation',[UserController::class,'sendInvitation']);
        Route::get('accept-invitation',[UserController::class,'acceptInvitation']);

        Route::post('save-random-question',[ChatController::class,'saveRandomQuestion']);

    });
});
