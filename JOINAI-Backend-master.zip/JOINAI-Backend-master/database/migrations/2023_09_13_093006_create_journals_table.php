<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('journals', function (Blueprint $table) {
            $table->id();

            $table->string('date');

            $table->text('end_of_day_review')->nullable();
            $table->text('improve_things')->nullable();
            $table->text('positive_affirmation')->nullable();
            $table->text('tomorrow_goal')->nullable();
            $table->text('morning_refinement')->nullable();
            $table->text('daily_goal')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('journals');
    }
};
