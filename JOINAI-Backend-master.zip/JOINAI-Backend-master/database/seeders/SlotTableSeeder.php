<?php

namespace Database\Seeders;

use App\Models\DaySlot;
use App\Models\Slot;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SlotTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
            Slot::truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        $period = new CarbonPeriod('00:00', '60 minutes', '23:00');
        $slots = [];
        foreach($period as $item){
            array_push($slots,$item->format("g:i A"));
        }


        foreach($slots as $slot)
        {
            Slot::create(['slot'=>$slot]);

        }




    }
}
