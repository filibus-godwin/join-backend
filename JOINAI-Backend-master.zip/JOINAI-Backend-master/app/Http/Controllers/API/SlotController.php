<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Journal;
use App\Models\Slot;
use App\Services\API\SlotService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SlotController extends Controller
{
    public $slotService;
    public function __construct(SlotService $slotService)
    {
        $this->slotService = $slotService;
    }

    public function index()
    {
        $data = Slot::all();
        return $data;
    }

    public function getSlotsData(Request $request)
    {
        $checkJournalData = Journal::where('date', Carbon::parse($request->date)->format('Y-m-d'))
            ->where('user_id',Auth::user()->id)
            ->select('id')
            ->first();


        return $this->slotService->getSlotsData($checkJournalData);




    }
}
