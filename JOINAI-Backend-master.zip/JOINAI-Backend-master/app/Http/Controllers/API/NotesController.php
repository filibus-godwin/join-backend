<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateNoteRequest;
use App\Http\Requests\UpdateNoteRequest;
use App\Models\Note;
use App\Services\API\NotesService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class NotesController extends Controller
{
    public $noteService;

    public function __construct(NotesService $service)
    {
        $this->noteService =  $service;
    }

    public function index(Request $request)
    {
        $newsRecord =  $this->noteService->index($request);

        if(sizeof($newsRecord) > 0)
        {

            if (isset($request) && $request->isMethod('post')) {
                $status = Response::HTTP_CREATED;
            }
            else{
                $status = Response::HTTP_OK;
            }

            return makeResponse('success','Record Found Successfully',$status,$newsRecord);
        }
        else{
            return makeResponse('error','Record Not Found',Response::HTTP_NOT_FOUND);
        }

    }

    public function save(CreateNoteRequest $request)
    {

        $note = new Note();

        $saveNotes =  $this->noteService->save($request,$note);

        if($saveNotes)
        {
            return makeResponse('success','Record Save Successfully',Response::HTTP_CREATED,$saveNotes);
        }
        else{
            return makeResponse('error','Error in Saving Notes',Response::HTTP_INTERNAL_SERVER_ERROR);
        }

    }

    public function update(UpdateNoteRequest $request)
    {
        $note = Note::find($request->id);

        $saveNotes =  $this->noteService->save($request,$note);

        if($saveNotes)
        {
            return makeResponse('success','Record Updated Successfully',Response::HTTP_OK,$saveNotes);
        }
        else{
            return makeResponse('error','Error in Updating Notes',Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function delete(Request $request)
    {
        try{
            $note =  Note::find($request->id);

            if(!$note)
            {
                return makeResponse('error','Record Not Found',Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            if($note->user_id !=  Auth::user()->id)
            {
                return makeResponse('error',"You are not authorised to perform this action",Response::HTTP_FORBIDDEN);
            }

            $note->delete();

            return makeResponse('success',"Note Deleted Successfully",Response::HTTP_NO_CONTENT);

        }
        catch (\Exception $e)
        {
            return makeResponse('error',"Error in deleting note: ".$e,Response::HTTP_INTERNAL_SERVER_ERROR);

        }
    }


}
