<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\API\GenerateChatResponseRequest;
use App\Models\Chat;
use App\Models\ChatMessage;
use App\Services\API\ChatService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ChatController extends Controller
{
    public $chatService;

    public function __construct(ChatService $service)
    {
        $this->chatService = $service;
    }

    public function fetchChat()
    {
        $message = Chat::select('id')->where('user_id', Auth::user()->id)->first();
        if ($message) {
            $getConversations = $this->chatService->fetchConversation($message->id);

            if (sizeof($getConversations['getConversation']) > 0) {
                $data = ['chat_id' => $message->id, 'conversations' => $getConversations['getConversation']];
                return makeResponse('success', 'Chat Found', Response::HTTP_OK, $data);
            } else {
                return makeResponse('error', 'No Previous Conversation Found', Response::HTTP_NOT_FOUND);

            }
        } else {
            return makeResponse('error', 'No Record Found', Response::HTTP_NOT_FOUND);
        }
    }

    public function generateResponse(GenerateChatResponseRequest $request)
    {
        $maxTokenLength = 12000;
        DB::beginTransaction();
        try {
            $chat = [];
            if ($request->chat_id) {

                $chat = Chat::find($request->chat_id);

                if (!$chat) {
                    return makeResponse('error', 'Chat ID is Incorrect', Response::HTTP_UNPROCESSABLE_ENTITY);
                }

                if ($chat->user_id != Auth::user()->id) {
                    return makeResponse('error', 'You are not authorised to perform this action', Response::HTTP_FORBIDDEN);
                }
            } else {
                $chat = new Chat;
                $chat->user_id = Auth::user()->id;
                $chat->save();
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return makeResponse('error', 'Error in Checking Chat: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);

        }

        try {


            $getConversations = $this->chatService->fetchConversation($request->chat_id);

        } catch (\Exception $e) {
            DB::rollBack();
            return makeResponse('error', 'Error in Fetching Chat: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        try {

            $saveUserMessage = $this->chatService->saveMessage($chat->id, 'user', $request->message);
            $getAllConversationsForSearch = $getConversations['getAllConversationsForSearch']->toArray();
            $getConversations = $getConversations['getAllConversation']->toArray();


            array_push($getAllConversationsForSearch,
                ['id'=>$saveUserMessage->id,'role' => $saveUserMessage->role, 'content' => $saveUserMessage->content]);

            array_push( $getConversations,
                ['role' => $saveUserMessage->role, 'content' => $saveUserMessage->content]);

        } catch (\Exception $e) {
            DB::rollBack();
            return makeResponse('error', 'Error in Save Message: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }

//        try{
//            $tokenizeMessages = $this->chatService->tokenizeMessage($getConversations);
//
//            dd($tokenizeMessages);
//
//        }
//        catch (\Exception $e)
//        {
//            DB::rollBack();
//            return makeResponse('error','Error in Counting Token: '.$e,Response::HTTP_INTERNAL_SERVER_ERROR);
//        }

//        dd($getConversations);

        try {
            $generateChatGPTResponse = $this->chatService->generateChatGPTResponse($request);

            array_push($getConversations,
                ['role' => $generateChatGPTResponse['role'], 'content' => $generateChatGPTResponse['content']]);
        } catch (\Exception $e) {
            DB::rollBack();
            return makeResponse('error', 'Error in Get ChatGPT Response: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        try {
            $saveChatGPTMessage = $this->chatService->saveMessage($chat->id, $generateChatGPTResponse['role'], $generateChatGPTResponse['content'], $generateChatGPTResponse['max_token'],$saveUserMessage->id);

            array_push($getAllConversationsForSearch,
                ['id'=>$saveChatGPTMessage->id,'role' => $saveChatGPTMessage->role, 'content' => $saveChatGPTMessage->content]);


            //delete message
            try {
                if ($generateChatGPTResponse['max_token'] >= $maxTokenLength) {
                    foreach ($getAllConversationsForSearch as $key => $conversation) {
                        if($key == 0 || $key == 1)
                        {
                            continue;
                        }
                        else{
                            $fetchConversationFromTable = ChatMessage::find($conversation['id']);
                            if ($fetchConversationFromTable) {
                                if($fetchConversationFromTable->max_token != 0)
                                {
                                    $max_token = $fetchConversationFromTable->max_token;


                                    $maxConversationToken = $fetchConversationFromTable->max_token;
                                    if ($generateChatGPTResponse['max_token'] - $maxConversationToken < $maxTokenLength) {
                                        if ($fetchConversationFromTable->parent_id != null) {
                                            ChatMessage::where('id',$fetchConversationFromTable->parent_id)->delete();
                                        }
                                        $fetchConversationFromTable->delete();

                                        ChatMessage::where('id',$saveChatGPTMessage->id)->update(
                                            ['max_token'=>$generateChatGPTResponse['max_token'] - $max_token]);

                                        break;
                                    }
                                    else{
                                        ChatMessage::where('id',$fetchConversationFromTable->parent_id)
                                            ->delete();
                                        $fetchConversationFromTable->delete();

                                        ChatMessage::where('id',$saveChatGPTMessage->id)->update(
                                            ['max_token'=>$generateChatGPTResponse['max_token'] - $max_token]);

                                    }
                                }

                            }

                        }


                    }
                }
            } catch (\Exception $e) {
                DB::rollBack();
                return makeResponse('error', 'Error in Delete Message: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
            }




            DB::commit();

            $data = [
                'chat_id' => $chat->id,
                'conversation' => ['role' => $saveChatGPTMessage->role,
                    'content' => $saveChatGPTMessage->content,
                    'max_token' => $generateChatGPTResponse['max_token']
                ]
            ];

            return makeResponse('success', 'Message Saved Successfully', Response::HTTP_OK, $data);
        } catch (\Exception $e) {
            DB::rollBack();
            return makeResponse('error', 'Error in Save Message: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }

    }

    public function saveRandomQuestion(GenerateChatResponseRequest $request)
    {
        DB::beginTransaction();
        try {
            $chat = [];
            if ($request->chat_id) {

                $chat = Chat::find($request->chat_id);

                if (!$chat) {
                    return makeResponse('error', 'Chat ID is Incorrect', Response::HTTP_UNPROCESSABLE_ENTITY);
                }

                if ($chat->user_id != Auth::user()->id) {
                    return makeResponse('error', 'You are not authorised to perform this action', Response::HTTP_FORBIDDEN);
                }
            } else {
                $chat = new Chat;
                $chat->user_id = Auth::user()->id;
                $chat->save();

                $saveFirstQuestion = $this->chatService->saveMessage($chat->id, 'system',
                    "You are a helpful life coach that answers questions and ask questions to provide a solution in the form of a coaching session.");
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return makeResponse('error', 'Error in Checking Chat: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);

        }

        try {
            $saveRandomQuestion = $this->chatService->saveMessage($chat->id, 'assistant', $request->message);

            DB::commit();

            $data = ['chat_id' => $chat->id, 'conversation' => ['role' => 'assistant',
                'content' => $request->message]];

            return makeResponse('success', 'Message Saved Successfully', Response::HTTP_OK, $data);
        } catch (\Exception $e) {
            DB::rollBack();
            return makeResponse('error', 'Error in Save Message: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
