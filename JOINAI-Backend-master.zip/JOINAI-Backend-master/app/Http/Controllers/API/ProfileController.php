<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\ProfileRequest;
use App\Models\User;
use App\Traits\UserTrait;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Testing\Fluent\Concerns\Has;

class ProfileController extends Controller
{
    use UserTrait;

    public function updateProfile(ProfileRequest $request)
    {
        try{
            if(isset($request->email) && $request->email)
            {
                $checkEmail =  User::where('email',$request->email)
                    ->where('id','!=',Auth::user()->id)->first();

                if($checkEmail)
                {
                    return makeResponse('error','The email has already been taken.',Response::HTTP_UNPROCESSABLE_ENTITY);
                }
            }


            $this->saveUser($request,Auth::user());
        }
        catch (\Exception $e)
        {
            return makeResponse('error','Error in Saving User: '.$e,Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        $data =  $this->userResponse(Auth::user());

        return makeResponse('success','Profile Updated Successfully',Response::HTTP_OK,$data);
    }

    public function changePassword(ChangePasswordRequest $request)
    {
        try{

            $checkPassword = Hash::check($request->old_password,Auth::user()->password);

            if(!$checkPassword)
            {
                return makeResponse('error','Invalid old password. Please provide the correct old password.',Response::HTTP_FORBIDDEN);
            }

            Auth::user()->password = Hash::make($request->new_password);
            Auth::user()->save();

        }
        catch (\Exception $e)
        {
            return makeResponse('error','Error in Changing Password: '.$e,Response::HTTP_INTERNAL_SERVER_ERROR);

        }

        return makeResponse('success','Password Change Successfully',Response::HTTP_OK);

    }

    public function deleteAccount()
    {
        try{
            Auth::user()->delete();

        }
        catch (\Exception $e)
        {
            return makeResponse('error','Error in Changing Password: '.$e,Response::HTTP_INTERNAL_SERVER_ERROR);

        }

        return makeResponse('success','Account Deleted Successfully',Response::HTTP_NO_CONTENT);

    }
}
