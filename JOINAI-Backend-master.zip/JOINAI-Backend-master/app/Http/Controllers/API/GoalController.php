<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateGoalRequest;
use App\Http\Requests\DeleteGoalRequest;
use App\Http\Requests\UpdateGoalRequest;
use App\Models\UserGoal;
use App\Services\API\GoalService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class GoalController extends Controller
{
    public $goalService;

    public function __construct(GoalService $goalService)
    {
        $this->goalService =  $goalService;
    }

    public function index($request = null)
    {
        $goalRecord =  $this->goalService->index();

        if(sizeof($goalRecord) > 0)
        {

            if (isset($request) && $request->isMethod('post')) {
                $status = Response::HTTP_CREATED;
            }
            else{
                $status = Response::HTTP_OK;
            }

            return makeResponse('success','Record Found Successfully',$status,$goalRecord);
        }
        else{
            return makeResponse('error','Record Not Found',Response::HTTP_NOT_FOUND);
        }

    }

    public function save(CreateGoalRequest $request)
    {
        //save goal
        $goal = new UserGoal();
        $saveGoal = $this->goalService->save($request,$goal);

        if($saveGoal)
        {
            return makeResponse('success','Record Save Successfully',Response::HTTP_CREATED,$saveGoal);
        }
        else{
            return makeResponse('error','Error in Saving Goal',Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    public function update(UpdateGoalRequest $request)
    {
        //save goal
        $goal =  UserGoal::find($request->id);

        if($goal->user_id  != Auth::user()->id)
        {
            return makeResponse('error',"You are not authorised to perform this action" ,Response::HTTP_FORBIDDEN);
        }

        $saveGoal = $this->goalService->save($request,$goal);

        if($saveGoal)
        {
            return makeResponse('success','Record Updated Successfully',Response::HTTP_OK,$saveGoal);
        }
        else{
            return makeResponse('error','Error in Saving Goal',Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function delete(DeleteGoalRequest $request)
    {
        try{
            $goal =  UserGoal::find($request->id);

            if(!$goal)
            {
                return makeResponse('error','Record Not Found',Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            if($goal->user_id !=  Auth::user()->id)
            {
                return makeResponse('error',"You are not authorised to perform this action",Response::HTTP_FORBIDDEN);
            }

            $goal->delete();

            return makeResponse('success',"Goal Deleted Successfully",Response::HTTP_NO_CONTENT);

        }
        catch (\Exception $e)
        {
            return makeResponse('error',"Error in deleting goal: ".$e,Response::HTTP_INTERNAL_SERVER_ERROR);

        }
    }
}
