<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\AcceptInvitationRequest;
use App\Http\Requests\SendInvitationRequest;
use App\Http\Requests\UnFriendRequest;
use App\Models\UserFriend;
use App\Notifications\SendInvitationNotification;
use App\Services\UserService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Notification;

class UserController extends Controller
{
    public $userService;

    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }

    public function unfriend(UnFriendRequest $request)
    {
        return $this->userService->unfriend($request);
    }

    public function friendList()
    {
        return $this->userService->friendList();
    }

    public function sendInvitation(SendInvitationRequest $request)
    {
        try {
            $deepLink = $request->deep_link_url;
            Notification::route('mail', $request->email)->notify(new SendInvitationNotification($deepLink));
            return makeResponse('success', 'Invitation Send Successfully', Response::HTTP_OK);

        } catch (\Exception $e) {
            return makeResponse('error', 'Error in Sending Invitation: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }

    }

    public function acceptInvitation(AcceptInvitationRequest $request)
    {
        $userID = Auth::user()->id;
        $data = UserFriend::where(function ($query) use ($userID, $request) {
            $query->where('user_id', $userID)->where('friend_id', $request->user_id);
        })
            ->orwhere(function ($query) use ($userID, $request) {
                $query->where('user_id', $request->user_id)->where('friend_id', $userID);
            })
            ->first();


        if ($data && $data->status == 1) {
            return makeResponse('success', 'User Request Already Accepted', Response::HTTP_OK);
        }


        return $this->userService->acceptFriendRequest($request,$data);
    }
}
