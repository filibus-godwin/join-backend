<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\JournalDeleteRequest;
use App\Http\Requests\SaveJournalRequest;
use App\Http\Requests\UpdateTaskStatus;
use App\Models\HourlyPlanner;
use App\Models\Journal;
use App\Services\API\JournalService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class JournalController extends Controller
{
    public $journalService;

    public function __construct(JournalService  $journalService)
    {
        return $this->journalService =  $journalService;
    }

    public function index(Request $request)
    {
        $getJournal = $this->journalService->index($request);

        if(sizeof($getJournal) > 0)
        {
            return makeResponse('success','Record Found Successfully',Response::HTTP_OK,$getJournal);
        }
        else{
            return makeResponse('error','Record Not Found',Response::HTTP_NOT_FOUND);
        }

    }

    public function save(SaveJournalRequest $request)
    {
        $journal = Journal::where('date',$request->date)
            ->where('user_id',Auth::user()->id)
            ->first();

        if(!$journal)
        {
            $journal = new Journal;
        }

        return $this->journalService->save($request,$journal);

    }

    public function updateTask(UpdateTaskStatus $request)
    {
        $getPlan = HourlyPlanner::find($request->id);

        if($getPlan->journal->date != Carbon::parse($request->date)->format('Y-m-d'))
        {
            return makeResponse('error', 'Record Not Found', Response::HTTP_NOT_FOUND);
        }

        if($getPlan->journal->user_id != Auth::user()->id)
        {
            return makeResponse('error', 'You are not authorised to perform this action', Response::HTTP_FORBIDDEN);
        }

        if($getPlan->is_complete == $request->is_complete)
        {
            return makeResponse('error', 'Task Status is already same', Response::HTTP_FORBIDDEN);

        }

        return $this->journalService->updateTask($request,$getPlan);
    }

    public function deleteJournal(JournalDeleteRequest $request)
    {
        try{
            $data =  Journal::find($request->id);

            if($data->user_id  != Auth::user()->id)
            {
                return makeResponse('error',"You are not authorised to perform this action" ,Response::HTTP_FORBIDDEN);
            }

            $data->delete();

            return makeResponse('success','Journal Deleted Successfully',Response::HTTP_NO_CONTENT);
        }
        catch (\Exception $e)
        {
            return makeResponse('error','Error in Deleting Journal: '.$e,Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
