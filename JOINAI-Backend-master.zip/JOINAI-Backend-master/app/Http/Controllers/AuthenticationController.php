<?php

namespace App\Http\Controllers;

use App\Http\Requests\ForgotPasswordRequest;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Http\Requests\ResetPasswordRequest;
use App\Models\User;
use App\Services\AuthenticationService;
use App\Traits\UserTrait;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;


class AuthenticationController extends Controller
{
    public $authService;
    use UserTrait;

    public function __construct(AuthenticationService $service)
    {
        $this->authService = $service;
    }

    public function login(LoginRequest $request)
    {
        return $this->authService->login($request);
    }


    public function logout()
    {
//        Auth::logout();
        Auth::user()->tokens()->delete();

        try {
            return makeResponse('success',  'You have Logged out successfully',Response::HTTP_OK);
        } catch (\Exception $e) {
            return makeResponse ( 'error',  'Error in Logout User: ' . $e,Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function register(RegisterRequest $request)
    {
        //save user
        try{
            $user = new User;
            $saveUser = $this->saveUser($request,$user);
        }
        catch (\Exception $e)
        {
            return makeResponse('error','Error in Saving User: '.$e,Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        //create User Token and Response
        try{
            Auth::loginUsingId($saveUser->id);
            $token = Auth::user()->createToken('CoachingAPP')->plainTextToken;

            $data = $this->userResponse(Auth::user());
        }
        catch (\Exception $e)
        {
            return makeResponse('error','Error in Creating Token: '.$e,Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        return makeResponse('success','User Registered Successfully,',Response::HTTP_CREATED,$data,$token);

    }

    public function forgotPassword(ForgotPasswordRequest $request)
    {
        return $this->authService->forgotPassword($request);
    }

    public function resetPassword(ResetPasswordRequest $request)
    {
        return $this->authService->resetPassword($request);
    }
}
