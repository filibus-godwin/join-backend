<?php

namespace App\Http\Requests;

use App\Models\UserFriend;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class UnFriendRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'friend_id' => $this->friendRule()
        ];
    }

    protected function friendRule()
    {
        $userID = Auth::user()->id;

        return [
            'required','exists:users,id',
            function ($attribute,$value,$fail) use ($userID)
            {
                $check = UserFriend::where('user_id', $userID)
                    ->where('friend_id', $value)
                    ->where('status', 1)
                    ->first();


                if ($check) {
                    return true;
                }

                return $fail('Invalid Friend ID');

            }
        ];



    }




    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            makeResponse('error', $validator->errors()->first(), Response::HTTP_UNPROCESSABLE_ENTITY)
        );
    }

}
