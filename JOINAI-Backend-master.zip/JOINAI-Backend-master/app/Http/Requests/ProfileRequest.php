<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Response;

class ProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'location' => 'sometimes',
//            'image' => 'sometimes|mimes:jpeg,jpg,png',
            'full_name' => 'sometimes',
            'email' => 'sometimes|email',
            'fcm_token' => 'sometimes',
            'is_join_journal_notification' => 'sometimes|boolean',
            'is_morning_refinement_notification' => 'sometimes|boolean',
            'night_notification_time' => 'required_if:is_join_journal_notification,1',
            'morning_notification_time' => 'required_if:is_morning_refinement_notification,1',


        ];
    }

    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            makeResponse('error', $validator->errors()->first(), Response::HTTP_UNPROCESSABLE_ENTITY)
        );
    }
}
