<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\HtmlString;

class SendInvitationNotification extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($url)
    {
        $this->url = $url;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {

        return (new MailMessage)
            ->subject(ucfirst(Auth::user()->full_name).' has sent you a friend request on  '.env("APP_NAME"))
            ->line(new HtmlString('You have received a friend request on <strong>' .env("APP_NAME").'</strong> from <strong>'.ucfirst(Auth::user()->full_name).'</strong>'))
            ->line('To accept the friend request simply click the link below:')
            ->action('Click On Me', $this->url)
            ->line(new HtmlString('By accepting this request, you will become friends with <strong>'.ucfirst(Auth::user()->full_name).'</strong> on <strong>'.env("APP_NAME").'</strong>'))
            ->line("If you have any questions or need assistance, please don't hesitate to reach out to and contact us.");

    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
