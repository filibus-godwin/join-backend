<?php

namespace App\Services\API;


use App\Models\HourlyPlanner;
use App\Models\Journal;
use Carbon\Carbon;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class JournalService
{
    public function index($request, $date = null)
    {
        if ($date) {
            $journal = Journal::where('date', Carbon::parse($date)->format('Y-m-d'))
                ->where('user_id',Auth::user()->id)
                ->first();

        } else {
            $journal = Journal::where('date', Carbon::parse($request->date)->format('Y-m-d'))
                ->where('user_id',Auth::user()->id)
                ->first();
        }




        $data = array();
        if ($journal) {
            $hourlyPlannerArray = array();
            $getJournalPlan = HourlyPlanner::where('journal_id',$journal->id)->get();
            foreach ($getJournalPlan as $hourlyPlanner) {
                $hourlyPlannerArray[] = [
                    'id' => $hourlyPlanner->id,
                    'slot_id' => $hourlyPlanner->slot_id,
                    'slot' => $hourlyPlanner->slot->slot,
                    'task' => $hourlyPlanner->task,
                    'is_complete' => $hourlyPlanner->is_complete
                ];
            }



            $data = ['journal' => $journal, 'hourlyPlanner' => $hourlyPlannerArray];
        }


        return $data;

    }

    public function save($request, $journal)
    {

        DB::beginTransaction();
        $journal->date = Carbon::parse($request->date)->format('Y-m-d');
        $journal->end_of_day_review = $request->end_of_day_review;
        $journal->improve_things = $request->improve_things;
        $journal->positive_affirmation = $request->positive_affirmation;
        $journal->tomorrow_goal = $request->tomorrow_goal;
        $journal->morning_refinement = $request->morning_refinement;
        $journal->daily_goal = $request->daily_goal;
        $journal->user_id = Auth::user()->id;
        $journal->save();

        if (sizeof($request->hourly_planner) > 0) {
            HourlyPlanner::where('journal_id', $journal->id)->delete();
            foreach ($request->hourly_planner as $hourlyPlanner) {
                $hourlyPlannerDB = new HourlyPlanner;
                $hourlyPlannerDB->slot_id = $hourlyPlanner['slot_id'];
                $hourlyPlannerDB->task = $hourlyPlanner['task'];
                $hourlyPlannerDB->is_complete = $hourlyPlanner['is_complete'];
                $hourlyPlannerDB->journal_id = $journal->id;
                $hourlyPlannerDB->save();
            }
        }
        DB::commit();

        $data = $this->index(null, $journal->date);

        return makeResponse('success', 'Journal Created Successfully', Response::HTTP_CREATED, $data);

    }

    public function updateTask($request,$getPlan)
    {
        try{
            $getPlan->is_complete  = $request->is_complete;

            $getPlan->save();

            return makeResponse('success','Task Updated Successfully',Response::HTTP_OK);
        }
        catch (\Exception $e)
        {
            return makeResponse('error',"Error in Updating Task Status: ".$e,Response::HTTP_INTERNAL_SERVER_ERROR);
        }

    }
}
