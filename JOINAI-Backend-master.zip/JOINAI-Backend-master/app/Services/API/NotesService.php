<?php

namespace App\Services\API;


use App\Models\Note;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class NotesService
{
    public function index($request)
    {
        $notes = Note::select('date','id','notes')->where('user_id',Auth::user()->id);
        if($request->date)
        {
            $notes = $notes->where('date',Carbon::parse($request->date)->format('Y-m-d'));
        }

        $notes = $notes->get();

        return $notes;
    }

    public function save($request,$note)
    {
        $note->notes = $request->notes;
        $note->user_id =  Auth::user()->id;
        $note->date = Carbon::parse($request->date)->format('Y-m-d');

        $note->save();

        $savedNote = new Note;
        $savedNote->id = $note->id;
        $savedNote->notes = $note->notes;
        $savedNote->date = $note->date;

        return $savedNote;
    }



}
