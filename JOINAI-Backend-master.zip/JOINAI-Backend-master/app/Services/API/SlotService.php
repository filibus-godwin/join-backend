<?php

namespace App\Services\API;


use App\Models\HourlyPlanner;
use App\Models\Slot;
use Illuminate\Http\Response;

class SlotService
{
    public function getSlotsData($checkJournalData = null)
    {
        $slots = Slot::all();

        $hourlyPlannerArray = array();

        foreach ($slots as $slot) {
            $getHourlyPlanner = HourlyPlanner::where('journal_id', $checkJournalData->id)
                ->where('slot_id', $slot->id)
                ->first();

            $hourlyPlannerArray[] = [
                'id' => isset($getHourlyPlanner->id) ? $getHourlyPlanner->id : null,
                'slot_id' => $slot->id,
                'task' => isset($getHourlyPlanner->task) ? $getHourlyPlanner->task : null,
                'is_complete' => isset($getHourlyPlanner->is_complete) ? $getHourlyPlanner->is_complete:null,
                'slot' => $slot->slot
            ];

        }

        return makeResponse('success','Record Fetch Successfully',Response::HTTP_OK,$hourlyPlannerArray);


    }
}
