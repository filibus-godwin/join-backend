<?php

namespace App\Services\API;


use App\Http\Requests\API\GenerateChatResponseRequest;
use App\Models\ChatMessage;
use Illuminate\Http\Client\Request;
use Illuminate\Http\Response;
use GuzzleHttp\Client;
use Rahul900day\Gpt3Encoder\Encoder;

class ChatService
{
    public function fetchConversation($chatID)
    {

        $getAllConversations = ChatMessage::where('chat_id', $chatID)
            ->select('role', 'content')
//            ->limit('30')
            ->get();


        if (sizeof($getAllConversations) <= 0) {
            $save = ChatMessage::create(['chat_id' => $chatID, 'role' => 'system',
                'content' => 'You are a helpful life coach that answers questions and ask questions to provide a solution in the form of a coaching session.']);
        }


        $getConversations = ChatMessage::where('chat_id', $chatID)
            ->where('role', '!=', 'system')
            ->select('role', 'content')->get();


        $getAllConversationsForSearch = ChatMessage::where('chat_id', $chatID)
            ->select('id','role', 'content')
//            ->limit('30')
            ->get();


        return ['getConversation' => $getConversations, 'getAllConversation' => $getAllConversations,'getAllConversationsForSearch'=>$getAllConversationsForSearch];

    }

    public function saveMessage($chatID, $userRole, $content,$max_token = 0,$parent_id =null)
    {
        $saveMessage = new ChatMessage;
        $saveMessage->chat_id = $chatID;
        $saveMessage->role = $userRole;
        $saveMessage->content = $content;
        $saveMessage->max_token = $max_token;
        $saveMessage->parent_id = $parent_id;

        $saveMessage->save();

        return $saveMessage;
    }

    public function generateChatGPTResponse(GenerateChatResponseRequest $request)
    {

        // $client = new Client();
        // $response = $client->post('https://api.openai.com/v1/chat/completions', [
        //     'headers' => [
        //         'Authorization' => 'Bearer ' . env('OPENAI_API_KEY'),
        //     ],
        //     'json' => [
        //         'model' => 'gpt-3.5-turbo-16k',
        //         'messages' => $getConversations,
        //         'max_tokens' => 150,
        //         'temperature' => 0.7

        //     ],
        // ]);

        // $data = json_decode($response->getBody(), true);


        // $response = ['role' => $data['choices'][0]['message']['role'],
        //     'content' => $data['choices'][0]['message']['content'],
        //     'max_token' => $data['usage']['total_tokens']
        // ];

        $client = new Client();
        $response = $client->post('https://pensyai.com/wp-json/mwai/v1/simpleChatbotQuery', [
            'headers' => [
                'Authorization' => 'Bearer ' . $request->bearerToken(),
            ],
            'json' => [
                'botId'=> "default",
                'prompt'=> $request->message,
            ],
        ]);

        $data = json_decode($response->getBody(), true);


        $response = [
            'role' => "assistant",// $data['choices'][0]['message']['role'],
            'content' => $data['data'],// $data['choices'][0]['message']['content'],
            'max_token' => 0,//$data['usage']['total_tokens']
        ];


        return $response;
    }

//    public function tokenizeMessage($getConversations)
//    {
//        try {
//            $encoding = TikToken::encodingForModel('gpt-3.5-turbo');
//        } catch (KeyError $e) {
//            $encoding = TikToken::getEncoding("cl100k_base");
//        }
//
//        if ('gpt-3.5-turbo') {
//            $numTokens = 0;
//
//            foreach ($getConversations as $message) {
//                $numTokens += 4; // Every message follows <im_start>{role/name}\n{content}<im_end>\n
//
//                foreach ($message as $key => $value) {
//                    $numTokens += strlen($encoding->encode($value));
//
//                    if ($key === "name") { // If there's a name, the role is omitted
//                        $numTokens -= 1; // Role is always required and always 1 token
//                    }
//                }
//            }
//
//            $numTokens += 2; // Every reply is primed with <im_start>assistant
//            return $numTokens;
//        } else {
//            throw new NotImplementedError(
//                "numTokensFromMessages() is not presently implemented for model."
//            );
//        }
//
//    }


}
