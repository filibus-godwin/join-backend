<?php

namespace App\Services\API;


use App\Models\UserGoal;
use Illuminate\Support\Facades\Auth;

class GoalService
{
    public function index()
    {

        $data = array();

        $goals = UserGoal::where('user_id',Auth::user()->id)->get();

        foreach($goals as $goal)
        {
            $data[] = [
                'id'=>$goal->id,
//                'title'=>$goal->title,
                'goal_type' => $goal->goal_type,
                'description'=>$goal->description
            ];
        }

        return $data;
    }

    public function save($request,$goal)
    {
        $goal->description =  $request->description;
        $goal->user_id = Auth::user()->id;
        $goal->goal_type = $request->goal_type;

        $goal->save();

        $savedGoal = new UserGoal();
        $savedGoal->id = $goal->id;
        $savedGoal->description = $goal->description;
        $savedGoal->goal_type = $goal->goal_type;

        return $savedGoal;
    }
}
