<?php

namespace App\Services;


use App\Models\UserFriend;
use App\Models\UserSetting;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class UserService
{
    public function unfriend($request)
    {
        try {
            $data = UserFriend::where('friend_id', $request->friend_id)->delete();
            return makeResponse('success', 'User Unfriend Successfully', Response::HTTP_OK);

        } catch (\Exception $e) {
            return makeResponse('error', 'Error in Unfriend User: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function friendList()
    {
        $userID = Auth::user()->id;
        $data = UserFriend::where(function ($query) use ($userID) {
            $query->where('user_id', $userID)->orWhere('friend_id', $userID);
        })->get();

        $friendArray = array();
        foreach ($data as $user) {

            if ($user->friend_id == Auth::user()->id) {

                $status = null;
                if ($user->status == 0) {
                    $status = 'pending by me';
                } elseif ($user->status == 1) {
                    $status = 'accepted';
                } elseif ($user->status == 2) {
                    $status = 'rejected by me';
                }


                $friendArray[] = ['user_id' => $user->user_id, 'status' => $status,
                    'full_name' => $user->user->full_name];

            } else {

                $status = null;
                if ($user->status == 0) {
                    $status = 'pending by other';
                } elseif ($user->status == 1) {
                    $status = 'accepted';
                } elseif ($user->status == 2) {
                    $status = 'reject by other';
                }


                $friendArray[] = [
                    'user_id' => $user->friend_id,
                    'status' => $status,
                    'full_name' => $user->friend->full_name
                ];

            }

        }

        if (sizeof($friendArray) > 0) {
            return makeResponse('success', 'Friend List Fetch Successfully', Response::HTTP_OK, $friendArray);
        }

        return makeResponse('error', 'Record Not Found', Response::HTTP_NOT_FOUND);

    }

    public function acceptFriendRequest($request,$data)
    {
        try {


            if(!$data)
            {
                $data = UserFriend::create(['friend_id'=> Auth::user()->id,
                    'user_id' => $request->user_id, 'status' => 1
                ]);
                return makeResponse('success', 'Invitation Accepted Successfully', Response::HTTP_CREATED,$data);

            }
            else{
                $data->status = 1;
                $data->save();

                return makeResponse('success', 'Invitation Accepted Successfully', Response::HTTP_CREATED,$data);

            }


        } catch (\Exception $e) {
            return makeResponse('error', 'Error in Accept Invitation: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
