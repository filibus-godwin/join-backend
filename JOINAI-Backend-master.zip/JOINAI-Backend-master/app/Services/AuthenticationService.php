<?php

namespace App\Services;


use App\Models\PasswordResetToken;
use App\Models\User;
use App\Models\Vendor;
use App\Notifications\ForgotPasswordNotification;
use App\Notifications\OtpNotification;
use App\Traits\AdminUserTrait;
use App\Traits\UserResponseTrait;
use App\Traits\UserTrait;
use App\Traits\VendorTrait;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Session;
use Mockery\Generator\StringManipulation\Pass\Pass;

class AuthenticationService
{
    use UserTrait;


    public function login($request)
    {
        $credentials = [
            'email' => $request->email,
            'password' => $request->password
        ];
        if ($request->remember_me) {
            $remember = true;

        } else {
            $remember = false;
        }


        if (Auth::attempt($credentials, $remember)) {
            $result = 'success';
            $message = 'Login Successful';
            $token = Auth::user()->createToken('CoachingAPP')->plainTextToken;
            $data = $this->userResponse(Auth::user());

            if ($request->fcm_token) {
                Auth::user()->fcm_token = $request->fcm_token;
            }

            if($request->timezone){
                Auth::user()->timezone = $request->timezone;
            }

            Auth::user()->save();

            return makeResponse($result, $message, Response::HTTP_OK, $data, $token);
        } else {
            return makeResponse('error', 'Invalid Credentials', Response::HTTP_UNAUTHORIZED);
        }
    }

    public function forgotPassword($request)
    {
        DB::beginTransaction();
        try {

            $token = rand(1000, 9999);

            $forgotPassword = new PasswordResetToken();
            $forgotPassword->email = $request->email;
            $forgotPassword->token = $token;

            $forgotPassword->save();

        } catch (\Exception $e) {
            return makeResponse('error', 'Error in Creating User Token: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        try {
            Notification::route('mail', $request->email)->notify(new ForgotPasswordNotification($forgotPassword));

        } catch (\Exception $e) {
            DB::rollBack();
            return makeResponse('error', 'Error in Sending Email To User: ' . $e, Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        DB::commit();
        return makeResponse('success','Mail Send To User Successfully',Response::HTTP_OK,$forgotPassword);
    }

    public function resetPassword($request)
    {
        try{
            $check = PasswordResetToken::where('email',$request->email);

            if($request->token)
            {
                $check = $check->where('token',$request->token);
            }

            $check = $check->first();


            if(!$check)
            {
                return makeResponse('error','Invalid Token',Response::HTTP_NOT_FOUND);
            }
        }
        catch (\Exception $e)
        {
            return makeResponse('error','Error in Checking User Token: '.$e,Response::HTTP_INTERNAL_SERVER_ERROR);
        }

        $user  = User::where('email',$request->email)->first();

        $this->saveUser($request,$user);

        $check->delete();

        return makeResponse('success','Password Reset Successfully',Response::HTTP_OK);
    }


}
