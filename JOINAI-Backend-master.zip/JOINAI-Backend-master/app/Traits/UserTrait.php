<?php

namespace App\Traits;

use App\Helper\ImageUploadHelper;
use App\Models\UserSetting;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;

trait UserTrait
{
    public function userResponse($user)
    {
        $data = [
            'id' => $user->id,
            'full_name' => $user->full_name,
            'email' => $user->email,
            'fcm_token' => $user->fcm_token,
            'location' => $user->location,
            'profile_image' => $user->image,
            'personal_info' => $user->personal_info,
            'timezone' => $user->timezone,
            'is_join_journal_notification' => (int)$user->is_join_journal_notification,
            'is_morning_refinement_notification' => (int)$user->is_morning_refinement_notification,
            'night_notification_time' => isset($user->userSetting) ? $user->userSetting->night_notification_time:null,
            'morning_notification_time' => isset($user->userSetting) ? $user->userSetting->morning_notification_time:null,
        ];

        return $data;
    }

    public function saveUser($request, $user)
    {
        if ($request->full_name) {
            $user->full_name = $request->full_name;
        }

        if ($request->email) {
            $user->email = $request->email;
        }


        if ($request->password) {
            $user->password = Hash::make($request->password);
        }

        if ($request->fcm_token) {
            $user->fcm_token = $request->fcm_token;
        }

        if ($request->location) {
            $user->location = $request->location;
        }

        if($request->timezone) {
            $user->timezone = $request->timezone;
        }
        if ($request->personal_info) {
            $user->personal_info = $request->personal_info;
        }

        if ($request->is_join_journal_notification) {
            $user->is_join_journal_notification = $request->is_join_journal_notification;

            $findSetting = UserSetting::where('user_id',$user->id)->first();

            if(!$findSetting)
            {
                $findSetting  = new UserSetting();
                $findSetting->user_id = Auth::user()->id;
            }

            $findSetting->night_notification_time = $request->night_notification_time;
            $findSetting->save();
        }
        elseif($request->is_join_journal_notification == 0)
        {
            $user->is_join_journal_notification = $request->is_join_journal_notification;
        }

        if ($request->is_morning_refinement_notification) {
            $user->is_morning_refinement_notification = $request->is_morning_refinement_notification;

            $findSetting = UserSetting::where('user_id',$user->id)->first();

            if(!$findSetting)
            {
                $findSetting  = new UserSetting();
                $findSetting->user_id = Auth::user()->id;

            }

            $findSetting->morning_notification_time = $request->morning_notification_time;
            $findSetting->save();
        }
        elseif($request->is_morning_refinement_notification == 0)
        {
            $user->is_morning_refinement_notification = $request->is_morning_refinement_notification;
        }


        if ($request->image) {
            $saveImage = ImageUploadHelper::uploadImage($request->image, 'upload/image/');

            if (file_exists($user->image)) {
                File::delete($user->image);
            }

            $user->image = $saveImage;
        }


        $user->save();

        return $user;

    }
}
