<?php


namespace App\Traits;


trait SendFirebaseNotificationTrait
{

    public function appointmentCreateNotification($fcmToken,$bodyData = null)
    {
        $title = 'You have an upcoming task';
        $message = $bodyData['full_name'].' you have an upcoming task at '. $bodyData['task'] .' - JOIN AI App';


        $data = array();
        $data ['title'] = $title;
        $data['body'] = $message;
        if ($bodyData) {
            $data['data'] = $bodyData;
        } else {
            $data['data'] = null;
        }


        $this->sendPushNotification($fcmToken, $data);

        return true;

    }

    public function joinJournalNotification($fcmToken,$bodyData = null)
    {
        $title = 'Reminder to Complete/JOIN Journal';
        $message = "Complete Your Today's Journal";


        $data = array();
        $data ['title'] = $title;
        $data['body'] = $message;
        if ($bodyData) {
            $data['data'] = $bodyData;
        } else {
            $data['data'] = null;
        }


        $this->sendPushNotification($fcmToken, $data);

        return true;

    }

    public function morningRefineMent($fcmToken,$bodyData = null)
    {
        $title = 'Reminder to Complete Morning Refinement';
        $message = "Complete Your Today's Journal Morning Refinement";


        $data = array();
        $data ['title'] = $title;
        $data['body'] = $message;
        if ($bodyData) {
            $data['data'] = $bodyData;
        } else {
            $data['data'] = null;
        }


        $this->sendPushNotification($fcmToken, $data);

        return true;

    }


    public function sendPushNotification($fcm, $dataBody)
    {

        $client = new \GuzzleHttp\Client(['verify' => false]);
        $fireBaseKey = env('FCM_SERVER_KEY');

        $request = $client->post(
            'https://fcm.googleapis.com/fcm/send',
            [
                'headers' => [
                    'Authorization' => 'key=' . $fireBaseKey,
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode([
                    "to" => $fcm,
                    "priority" => "high",
                    "content_available" => true,
                    "mutable_content" => true,
                    "time_to_live" => 0,
//                    "notification" => $dataBody,
                    "data" => $dataBody,
                    "notification" => $dataBody
                ])
            ]
        );

        $response = $request->getBody();
        $response = json_decode($response);


        if ($response->success > 0) {
            return true;
        } else {
            return false;
        }

    }
}
