<?php

namespace App\Console\Commands;

use App\Models\Journal;
use App\Traits\SendFirebaseNotificationTrait;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SendHourlyPlannerNotification extends Command
{
    use SendFirebaseNotificationTrait;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hourly_planner:notification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This is used to Send Hourly Planner Notification';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try{
            $getTodayJournals = Journal::where('date',Carbon::now()->format('Y-m-d'))->get();

            foreach($getTodayJournals as $getTodayJournal)
            {
                if(sizeof($getTodayJournal->hourlyPlanner) > 0)
                {
                    foreach($getTodayJournal->hourlyPlanner as $hourlyPlanner)
                    {
                        if($hourlyPlanner->is_complete == 0 && $hourlyPlanner->is_notification_send == 0)
                        {
                            $targetTime = Carbon::createFromTimeString($hourlyPlanner->slot->slot);
                            $halfHourBeforeTargetTime = $targetTime->subMinutes(30)->format('H:i');
                            if($getTodayJournal->user->timezone)
                            {
                                $currentTime = Carbon::now($getTodayJournal->user->timezone)->second(0)->microsecond(0)->format('H:i');
                            }
                            else{
                                $currentTime = Carbon::now()->second(0)->microsecond(0)->format('H:i');
                            }


                            if ($currentTime === $halfHourBeforeTargetTime) {
                                $fcmToken = $getTodayJournal->user->fcm_token;
                                if($fcmToken)
                                {
                                    $dataBody = ['task'=>$hourlyPlanner->slot->slot,'full_name'=>$getTodayJournal->user->full_name];
                                    $this->appointmentCreateNotification($fcmToken,$dataBody);
                                }

                                $hourlyPlanner->is_notification_send = 1;
                                $hourlyPlanner->save();

                            }

                        }
                    }
                }
            }

        }
        catch (\Exception $e)
        {
            dd('Error came in sending notification: '.$e);
        }
    }
}
