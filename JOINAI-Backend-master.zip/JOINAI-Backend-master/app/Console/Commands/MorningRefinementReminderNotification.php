<?php

namespace App\Console\Commands;

use App\Models\Journal;
use App\Models\NotificationSend;
use App\Models\User;
use App\Traits\SendFirebaseNotificationTrait;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class MorningRefinementReminderNotification extends Command
{
    use SendFirebaseNotificationTrait;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'morning:refinement';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Reminder to Complete Morning Refinement';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        try {
            $users = User::where('is_morning_refinement_notification', 1)->get();

            foreach ($users as $user) {
//                $userJournal = Journal::where('date', Carbon::now()->format('Y-m-d'))
//                    ->where('user_id', $user->id)
//                    ->first();


                $notification  = NotificationSend::where('user_id',$user->id)
                    ->where('date',Carbon::now()->timezone($user->timezone)->format('Y-m-d'))
                    ->where('type','morning_notification')
                    ->first();

                if(!$notification)
                {
                    if (isset($user->userSetting)) {
                        $time = Carbon::now()->timezone($user->timezone)->format('g:iA');

                        $userTime = Carbon::createFromFormat('g:i A', $user->userSetting->morning_notification_time)->format('g:iA');




                        if ($time === $userTime) {
                            $fcmToken = $user->fcm_token;
                            if ($fcmToken) {
                                $this->morningRefineMent($fcmToken);
                            }

                            $notificationCreate = new NotificationSend();

                            $notificationCreate->user_id = $user->id;
                            $notificationCreate->date = Carbon::now()->timezone($user->timezone)->format('Y-m-d');
                            $notificationCreate->type = 'morning_notification';

                            $notificationCreate->save();
                        }

                    }

                }



            }
        } catch (\Exception $e) {
            dd('Error came in sending notification: ' . $e);
        }
    }
}
